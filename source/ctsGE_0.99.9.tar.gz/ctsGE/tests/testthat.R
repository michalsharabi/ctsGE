library(testthat)
library(ctsGE)

test_check("ctsGE")
